"""Provide the Stylesheet class."""

from .base import PRAWBase


class Stylesheet(PRAWBase):
    """Represent a stylesheet."""
